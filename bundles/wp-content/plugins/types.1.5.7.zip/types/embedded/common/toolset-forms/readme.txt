Usage:

include 'common/forms/bootstrap.php';
// API call, returns HTML formatted output
$html = wptoolset_form_field( $field_db_data );

To get HTML and rest of the scripts queued,
call function before queue_styles WP hook.




